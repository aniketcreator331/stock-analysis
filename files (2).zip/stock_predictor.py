import requests
import pandas as pd
from sklearn.linear_model import LinearRegression
import datetime
import os

ALPHA_VANTAGE_API_KEY = os.getenv('ALPHA_VANTAGE_API_KEY')
STOCK_SYMBOL = 'AAPL'
API_URL = "https://www.alphavantage.co/query"

def fetch_stock_data(symbol, api_key):
    params = {
        "function": "TIME_SERIES_DAILY",
        "symbol": symbol,
        "apikey": api_key,
        "outputsize": "compact"
    }
    response = requests.get(API_URL, params=params)
    data = response.json()
    timeseries = data.get("Time Series (Daily)", {})
    df = pd.DataFrame.from_dict(timeseries, orient='index').sort_index()
    df = df.rename(columns={"4. close": "close"})
    df["close"] = df["close"].astype(float)
    df.index = pd.to_datetime(df.index)
    return df

def predict_next_day(df):
    df = df.reset_index()
    df['day_num'] = (df['index'] - df['index'].min()).dt.days
    X = df[['day_num']]
    y = df['close']

    model = LinearRegression()
    model.fit(X, y)
    next_day = X['day_num'].max() + 1
    prediction = model.predict([[next_day]])
    return prediction[0]

if __name__ == "__main__":
    if not ALPHA_VANTAGE_API_KEY:
        print("Please set ALPHA_VANTAGE_API_KEY environment variable.")
        exit(1)
    df = fetch_stock_data(STOCK_SYMBOL, ALPHA_VANTAGE_API_KEY)
    predicted_price = predict_next_day(df)
    print(f"Predicted price for next day: ${predicted_price:.2f}")