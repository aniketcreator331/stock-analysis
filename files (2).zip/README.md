# Stock Price Prediction with Alpha Vantage

## Overview
This project predicts the next day's closing price for a given stock using historical data from the Alpha Vantage API and a simple linear regression model.

## Setup

1. Create a virtual environment and install dependencies:

    ```bash
    python -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    ```

2. Get an Alpha Vantage API key [here](https://www.alphavantage.co/support/#api-key), and set it as an environment variable:

    ```bash
    export ALPHA_VANTAGE_API_KEY=your_api_key
    ```

3. To run:

    ```bash
    python stock_predictor.py
    ```

## GitHub Actions Workflow
The included GitHub Actions workflow automatically runs the prediction script on push.

## Customize
- Change `STOCK_SYMBOL` in `stock_predictor.py` to any stock ticker you like!